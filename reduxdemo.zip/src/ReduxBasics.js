//Level 1
/*
import {applyMiddleware,createStore} from 'redux'
import logger from "redux-logger"

const reducer = (state,action) => {
    if(action.type==='INC'){
        return state + action.payload;
    }
    if(action.type==='DEC'){
        return state - action.m;
    }
    if(action.type==='E'){
        throw new Error("Oops")
    }
    return state;

}

const myLogger = (store) => (next) => (action) => {
    console.log("action Fires ",action);
next(action)
}

const error=(store) => (next) => (action) => {
    try{
        next(action)
    }
    catch(e){
        console.log('Ohh Error Occurrred !',e)
    }
}

const middleware=applyMiddleware(logger,myLogger,error);
//creating store and attaching to reducer with initial state
const store = createStore(reducer,1,middleware);

//subscribe store to get new state
store.subscribe(() => {
    console.log('Stpre Changed :' + store.getState())
});


//Dispatch action to invoke reducer
store.dispatch({type:'INC',payload:1});
store.dispatch({type:'INC',payload:3});
store.dispatch({type:'DEC',m:20});  //type shudnt be changed where as payload can be changed
store.dispatch({type:'E',m:20});


//Level 3 Combined reducers
import {combineReducers,applyMiddleware,createStore} from 'redux'
import {composeWithDevTools} from 'redux-devtools-extension'
import logger from 'redux-logger'



const userReducer=(state={},action)=>{
    console.log(state);
    switch(action.type){
        case "CHANGE_NAME":{
            state={...state,name:action.payload}
            break;

        }
        case "CHANGE_AGE":{
            state={...state,age:action.payload}
            break;
        }
    }
    return state;
}

const tweetReducer=(state=[],action)=>{
    return state;
}
const reducers= combineReducers({
    user:userReducer,
    tweets:tweetReducer
})

const store=createStore(reducers,composeWithDevTools(applyMiddleware(logger)))


//subscribe store to get new state
store.subscribe(() => {
    console.log('Stpre Changed :' + store.getState())
});

store.dispatch({type:'CHANGE_NAME',payload:'Asha'})
store.dispatch({type:'CHANGE_AGE',payload:24})

*/

//composeWithDevTools
import {applyMiddleware,createStore} from 'redux'
import logger from 'redux-logger'
import {composeWithDevTools} from 'redux-devtools-extension'
import thunk from 'redux-thunk'

import axios from 'axios'

const initialState={
    fetching:false,
    fetched:false,
    user:[],
    error:null
}

const reducer =(state=initialState,action) => {
    switch(action.type){
        case "FETCH_USERS_START" :{
            return {...state,fetching:true}
        }
        case "FETCH_USERS_ERROR" :{
            return {...state,fetching:false,error:action.payload}
        }
        case "RECEIVE_USERS" :{
            return {...state,fetching:false,fetched:true,users:action.payload}
        }
        
    }
    return state;
}

const middleware=applyMiddleware(logger,thunk);
const store=createStore(reducer,composeWithDevTools(middleware));

store.dispatch((dispatch)=>{

    dispatch({type:'FETCH_USERS_START'});

    axios.get('https://jsonplaceholder.typicode.com/users')
    .then((response) =>{
        dispatch({type:'RECEIVE_USERS',payload:response})
    })
    .catch((error) => {
        dispatch({type:'FETCH_USERS_ERROR',payload:error})
    });
})

//Redux Routing 
/* 
// Level 5 - Redux-routing 
// npm install redux-routing --save
import { applyMiddleware, createStore } from 'redux'
import { createMiddleware, History, match,
             navigate, reducer, route } 
             from 'redux-routing'
 
// define routes
const routes = [
  route('/', () => console.log('navigated to /')),
  route('/foo', () => console.log('navigated to /foo')),
  route('/foo/:bar', () => console.log('navigated to /foo/:bar'))
]
 
// create routing middleware, set up with HTML5 History
const middleware = createMiddleware(History)
 
// create store with middleware
const createStoreWithMiddleware =
     applyMiddleware(middleware)(createStore)
     
const store = createStoreWithMiddleware(reducer)
 
// subscribe to changes
store.subscribe(() => {
  const route = store.getState()
  const matched = match(route.href, routes)
 
  if (matched) {
    matched.handler()
  } else {
    console.log('404 not found')
  }
})
 
// start navigating
store.dispatch(navigate('/'))
// logs 'navigated to /'
store.dispatch(navigate('/foo'))
// logs 'navigated to /foo'
store.dispatch(navigate('/foo/123'))
// logs 'navigated to /foo/:bar'
store.dispatch(navigate('/foo/bar/baz'))
*/



