import React,{Fragment,Component}  from 'react'
import ReactDOM from 'react-dom'



export default class UsingRefs extends Component {

    constructor(props){
        super(props);
        this.state={data:''}
        this.updateState= this.updateState.bind(this);
        this.clearInput= this.clearInput.bind(this);
    }
    updateState(e){
        this.setState({data:e.target.value});
    }
    clearInput(){
        this.setState({data:''})
        ReactDOM.findDOMNode(this.refs.myInput).focus(); 
    }
    render(){
        return (
            <div>
                <input value={this.state.data} onChange={this.updateState} ref="myInput" />
                <button onClick={this.clearInput}>Clear</button>
                <h4>{this.state.data}</h4>
          <FragmentApp title="Welcome...." clearInput={this.clearInput} />
            </div>
        );
    }
    
}
const FragmentApp = (props) => ( 
<Fragment>
    <p> {props.title} Asha</p>
    <p> Iam Awesome</p>
    <button onClick={props.clearInput}>Clear</button>
    

</Fragment>)

