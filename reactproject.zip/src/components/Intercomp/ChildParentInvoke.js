import React,{Component} from 'react'

//parent
export default class ChildParentInvoke extends Component{
    constructor(props){
        super(props);
        this.state={
            'data':'Initial data..'
        }
        this.updateState=this.updateState.bind(this);
    }
    updateState(event){
        this.setState({
            'data':event.target.value
        })
    }
    render(){
        return( <div  >
           <h3 className="text-success">Parent Component: </h3>   <h5 className="text-danger bg-success">{this.state.data}</h5>
          <h3 className="container"> Child Component</h3> <Child childData={this.state.data} childChange={this.updateState} />
        </div>
        )
    }
}

//Child
class Child extends Component{
    render(){
        return (
            <div>
                <input type="text" value={this.props.childData} onChange={this.props.childChange} />

               <div>Child Component : {this.props.childData}</div> 
            </div>
        );
    }
}