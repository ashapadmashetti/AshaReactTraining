import React from 'react'

const state={
    number:0,
    authToken:'Asha1234',
    sessionId:'',
    isAuthenticated:false
};

const NumberContext = React.createContext(state.number);

export default NumberContext;