import React,{Component} from 'react'
import NumberContext from './context'
import './Context.css'

const Counter = (props) => {
    return (
        <NumberContext.Consumer>
            {val => <h1>{val} 💪</h1>}
        </NumberContext.Consumer>
    )
}

export default class ContextApp extends Component{
    constructor(props){
        super(props)
        this.state={number:0}
        this.onDecHandler=this.onDecHandler.bind(this);
        this.onIncHandler=this.onIncHandler.bind(this);
    };
    //Increment 
    onIncHandler(){
        this.setState({number:this.state.number + 1})
    }
    onDecHandler(){
        this.setState({number:this.state.number - 1})
    }
    render(){
        return (
            <div>
                <h1 className="App-title" > React Context API v16.3.1</h1>
                <NumberContext.Provider value={this.state.number}>
                <Counter/>
                </NumberContext.Provider>
                <button onClick={this.onIncHandler} className="btn">Increment</button>
                <button onClick={this.onDecHandler} className="btn">Decrement</button>
            
            </div>
        )
    }
}

