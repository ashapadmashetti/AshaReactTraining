import React from 'react';
//import Parent from './ErrorHandlling';

// Note : *Will* hooks are going to be removed in future versions
export default class CompLifeCycle extends React.Component {

   constructor(props) {
      super(props);		
      this.state = {
         data: 0,
         msg: 'Initial data...',
         newmsg:'Nodata'
      }
      this.setNewNumber = this.setNewNumber.bind(this)
      this.updateState = this.updateState.bind(this);     
   };
   setNewNumber(e) {
      this.setState({data: this.state.data + 1})
   }
   updateState(e) {
      this.setState({msg:e.target.value});
   }      
   render() {
      return (
         <div>          
             <button  onClick = {this.setNewNumber}>INCREMENT</button>                       
            
             <Content myNumber = {this.state.data} ></Content>
            <br/>
             <input type = "text" value = {this.state.msg} 
               onChange = {this.updateState} />
             <h3>{this.state.msg}</h3>               
         </div>
      );
   }
}
//Child 
class Content extends React.Component{
    constructor(props){
        super(props)
        console.log(props.myNumber);
        //load data from cache (local storage)
        console.log('1. Content Child Constructer Fired ');
        this.handleScroll=this.handleScroll.bind(this);
    }
    componentWillMount(){
        console.log('2. ComponentWill Mount  =>' + this.props.myNumber);

    }
    handleScroll(){
        console.log('handle Scroll is Executed');
    }

    componentDidMount(){ //importatnt ohook fires only once 
        console.log('3. Component DID Mount reset data or reinitialize data');
        console.log('3. Component DID Mount =>' + this.props.myNumber);
        //makes ajax calls here or load some mocked data and update state
        window.addEventListener('scroll',this.handleScroll);
        
    }
    //this method will be invoked when a component is receiving
    // new props component will receive props
    //wont be called for initial rendering 
    componentWillReceiveProps(nextProps){
        console.log('4. Component Will Recevie Propsset default props here');
        console.log('4. Props in Component wiil receive : =>' + nextProps.myNumber);
        this.setState({isPassed:nextProps.myNumber})

    }
    shouldComponentUpdate(nextProps,nextState){
        console.log("Decide whether to re-render or not");
        console.log(nextState);
        //Dont rerender if score doesnt change
        console.log(this.props.myNumber);
        //console.log(nextProps.myNumber);
       // if(nextProps.myNumber==this.props.myNumber){
           // console.log('Componet is not rendered')
           // return false;
        //}
        //console.log('5. Component is rendered')
        if(nextProps.myNumber>5){
            return true;
        }
        else{
            return false;
        }
    }
    componentWillUpdate(nextProps,nextState){
        console.log('6. Component Will Update!' + nextProps.myNumber + ' state - ' +nextState.myNumber)

    }
    //invoke imediately after the componet 
    //access real dom using jquery
    componentDidUpdate(prevProps,prevState){
        console.log('7. Component DID Update! - You can rollback state here ')
    }
    componentWillUnmount(){
        //avoid memory leak - unsubscribe to web sockets
        console.log('Componet will unmount - release the resources here');
        window.removeEventListener('scroll',this.handleScroll);
    }
    //error handling
    componentDidCatch(err){
        console.log('Some error has occured log it in server in mongodb')

    }
    render(){
        return (
            <div>
                <h3>{this.props.myNumber}</h3>
            </div>
        )
    }
}