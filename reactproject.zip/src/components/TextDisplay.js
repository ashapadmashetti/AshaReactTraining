import React,{Component} from 'react';
import ReactDOM from 'react-dom'

export default class TextDisplay extends Component
{   
   
   render()
    {
         var myStyle={
             fontSize:20,
             color:'#FF0000'
         }
        return(
           <div >
            Welcome: <span style={myStyle}> {this.props.text} </span>
           
           </div>
        );
    }
}