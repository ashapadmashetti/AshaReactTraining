import React,{Component} from 'react'


export default class Footer extends Component {
 render(){
     return (
         <div> <h2 className="text-danger text-center"> Copyright reserved to Asha </h2>
         
         </div>
     );
 }
}
