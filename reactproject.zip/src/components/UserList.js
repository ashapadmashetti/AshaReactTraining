import React from 'react';

import UserListElement from './UserListElement';
export default class UserList extends React.Component
{    
    render()
    {
        return(
            <table className="table">
                <thead>
                <tr className="bg-primary">
                    <th>ID</th>
                    <th>Username</th>
                    <th>Job</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
                </thead>
                <tbody>
                { this.props.users.length>0 ? this.props.users.map((user, index) => {
                    return(
                      <UserListElement key={user.id} user={user}/> 
                    );
                }) : <tr> <td colSpan="4">No Records!</td></tr>}
                </tbody>
            </table>
        );
    }
}