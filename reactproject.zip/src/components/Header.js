import React,{Component} from 'react'


export default class Header extends Component {
 render(){
     return (
         <div> 
 <h2 className="text-info text-center">{this.props.title ? this.props.title : Header.defaultProps.title} </h2> 

       {/*  <h3> Verizon Data Services</h3>*/}
         </div>
     );
 }
}

Header.defaultProps={
    title:'Welcome to React Project'
};