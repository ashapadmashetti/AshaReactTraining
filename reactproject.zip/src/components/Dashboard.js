import React,{Component} from 'react'
import Header from './Header'
import Footer from './Footer'
import Grid from './Grid'
import StateApp from './StateApp';
import TextInput from './TextInput'
import ChildParentInvoke from './Intercomp/ChildParentInvoke'
import MyHOC from './HOC'
import TextInputWithHOC from './TextInputWithHOC'
import ContextApp from './ContextAPI/ContextApp'
import UsingRefs from './Intercomp/UsingRefs'
import CompLifeCycle from './LifeCycleFolder/CompLifeCycle'
import Parent from './LifeCycleFolder/ErrorHandling'
import WeatherComponent from './RestDemo'

export class Dashboard extends Component {
 render(){
     return (
         <div> 
         <Header  title="Welcome to Asha's World"/>
        {/* <Grid/> */}
{/* <StateApp/> */}
{/* <TextInput /> */}
{/* <ChildParentInvoke /> 
<MyHOC/>
<TextInputWithHOC/>
<ContextApp/>
 <UsingRefs/>
<Parent/>
<CompLifeCycle/>*/}
<WeatherComponent/>
        <Footer/>
         </div>
     );
 }
}

