import React,{Component} from 'react';

const TextInputWithHOC = (TextDisplay) => 

    class extends Component{
        constructor(props){
            super(props);
            this.state={inputText:'Asha',Title:'Awesome'};
            this.handleChange=this.handleChange.bind(this);
        }
    
    handleChange(event)
    {
        this.setState({
            inputText:event.target.value
        })
    }
    
    render()
    {
        return(
           <div>
              <div>Enter Name </div>
               <input type="text" value={this.state.inputText} onChange={this.handleChange} /> 
               <TextDisplay {...this.props} {...this.state} />
           </div>
        );
    }

};



class cc extends Component
{   
   
   render()
    {
         var myStyle={
             fontSize:20,
             color:'#FF0000'
         }
        return(
           <div >
               <div>{this.props.Title} </div>
            Welcome: <span style={myStyle}> {this.props.inputText} </span>
           </div>
        );
    }
}

export default TextInputWithHOC(cc)