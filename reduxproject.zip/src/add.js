export const add =(x,y) =>{
return x+y;
}