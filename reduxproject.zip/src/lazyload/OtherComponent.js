import React from 'react'

export const OtherComponent =(props) => {
    return (
        <div>
            <h1>Hi Iam dynamic component</h1>
        </div>
    )
}

export default OtherComponent