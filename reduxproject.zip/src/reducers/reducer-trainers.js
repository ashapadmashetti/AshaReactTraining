import data from '../store/store'

export default (state=null,action) => {
    return state=data; //returning initial state of trainer list
}

















